$(document).snowfall({
	flakeCount : 100,
	maxSpeed : 5,
	maxSize : 5,
	round: true,
	collection : '#wish-box'
});

$("#show-form").on("click", function(){
	$(this).next().slideToggle()
});