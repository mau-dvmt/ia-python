from bottle import run, route, static_file, template, request
import json

def get_wishes():
    try:
        my_file = open("wishes.json", "r")
        wishes = json.loads(my_file.read())
        my_file.close()

        return wishes
    except:
        my_file = open("wishes.json", "w")
        wishes = []
        my_file.write(json.dumps(wishes))
        my_file.close()

        return wishes

@route("/")
def index():
    return template("index", wishes=get_wishes())

@route("/new", method="POST")
def add_new_wish():
    wish = {}
    wish["title"] = getattr(request.forms, "title")
    wish["link"] = getattr(request.forms, "link")
    wish["prio"] = getattr(request.forms, "prio")

    wishes = get_wishes()
    wishes.append(wish)

    my_file = open("wishes.json", "w")
    my_file.write(json.dumps(wishes, indent=4))
    my_file.close()
    
    return template("index", wishes=get_wishes())

@route("/static/<filename>")
def static_files(filename):
    return static_file(filename, root="static")

run(host="localhost", port=8000)
