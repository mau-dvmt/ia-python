from bottle import run, route, error, template, static_file, request
import json

def get_movies():
    try:
        my_file = open("movies.json", "r")
        movies = json.loads(my_file.read())
        my_file.close()
        
        return movies
    except FileNotFoundError:
        my_file = open("movies.json", "w")
        movies = []
        my_file.write(json.dumps(movies))
        my_file.close()

        return movies

@route("/")
def index():
    return template("index", movies=get_movies())


@route("/movies/<movie_id>")
def movie(movie_id):
    movies = get_movies()

    found_movie = None
    for movie in movies:
        if movie["id"] == int(movie_id):
            found_movie = movie

    if found_movie == None:
        return template("movie-not-found")
    else:
        return template("movie", movie=found_movie)

@route("/add_movie")
def add_movie():
    return template("add-movie")


@route("/save_movie", method="POST")
def save_movie():
    movie = {}
    movie["title"] = getattr(request.forms, "title")
    movie["actors"] = [
        getattr(request.forms, "actor-1"),
        getattr(request.forms, "actor-2"),
        getattr(request.forms, "actor-3")
    ]
    movie["poster"] = getattr(request.forms, "poster")

    movies = get_movies()
    highest_id = 0
    for m in movies:
        if int(m["id"]) > highest_id:
            highest_id = int(m["id"])

    movie["id"] = highest_id + 1

    movies.append(movie)

    my_file = open("movies.json", "w")
    my_file.write(json.dumps(movies, indent=4))
    my_file.close()

    return template("index", movies=movies)


@route("/static/<filename>")
def server_static(filename):
    return static_file(filename, root="static")


run(host="0.0.0.0", port=8080)
