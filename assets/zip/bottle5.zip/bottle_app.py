from bottle import *

@route("/")
def index():
    user = {
            "name": "Anton",
            "age": 28,
            "city": "Lund"
        }
    return template("index", user=user)

@route("/add_user")
def add_user():
    return template("add_user")

@route("/save_user", method="POST")
def save_user():
    name = request.forms.get("name")
    info = request.forms.get("info")

    my_file = open("users/"+name+".txt", "w")
    my_file.write(info)
    my_file.close()
    
    print(name)
    print(info)

    return "Användare sparad!"


# Start our web server
run(host="0.0.0.0", port=8006, reloader=True)
