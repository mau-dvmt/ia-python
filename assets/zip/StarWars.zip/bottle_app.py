# Import all the functions we need from bottle
from bottle import run, route, error, template, static_file, request
# Import the json library
import json

def get_votes():
    '''Returns an object (dictionary) with the results from file:
    "staic/standings.txt"

    The result is in JSON format, ex.
	{
		"empire": 13,
		"rebels": 9
	}
	
    Returns:
	dict : The results
    '''

    # Opens the file "static/standings.txt" in "read" mode
    my_file = open("static/standings.txt", "r")
    # Reads and converts the file content (JSON-string) to Python datatype (dictionary)
    votes = json.loads(my_file.read())
    # Closes the file
    my_file.close()

    # Return the votes
    return votes

@route("/vote", method="POST")
def create_vote():
    '''Register a vote, and returns the start page
    
    Notes:
        - The vote is sent by a form (method = POST) with the key "vote"
        - The vote is added to the file "static/standings.txt"
    
    Returns:
        template : index
    '''
    # Recieves the vote send from a from (method=POST) by the key "vote"
    vote = request.forms.get("vote")
    # Get the current standing (votes)
    votes = get_votes()
    # If the vote is for the empire
    if vote == "empire":
        # Add one vote to the empire
        votes["empire"] += 1
    # Else if the vote is for rebels
    elif vote == "rebels":
        # Add one vote to the empire
        votes["rebels"] += 1

    # Opens the file "static/standings.txt" in "write" mode
    my_file = open("static/standings.txt", "w")
    # Converts the standings dictionary (current_votes) to JSON-format and saves it to text file
    my_file.write(json.dumps(votes))
    # Closes the file
    my_file.close()

    # Creates and returns the template "index" (views/index.html) with the current standings
    return template("index", votes=get_votes())

@route("/")
def index():
    '''Returns the start page
    
    Returns:
            template : index
    '''
    # Creates and returns the template "index" (views/index.html) with the current standings
    return template("index", votes=get_votes())

@route("/static/<filename:path>")
def server_static(filename):
    '''Handles the routes to our static files
    
    Returns:
            file : the static file requested by URL	
    '''
    return static_file(filename, root="static")

# Start our web server
run(host="0.0.0.0", port=8000, reloader=True)
