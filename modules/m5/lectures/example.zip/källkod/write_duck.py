# -*- coding: utf-8 -*-

# Öpnna en fil och skriv till den
contents = 'Jag och min gummianka'
my_file = open("file.txt", "w")
my_file.write(contents)
my_file.close()
print 'Skrev till file.txt'

