# -*- coding: utf-8 -*-

# Öppna en fil och läs innehållet
try:
    my_file = open("file.txt", "r")
    contents = my_file.read()
    print "fil: " + my_file.name
    print "innehåll: " + contents
    my_file.close()
except IOError:
    print "Ajaj! Filen finns inte"
