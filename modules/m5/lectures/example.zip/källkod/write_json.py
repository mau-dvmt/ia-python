# -*- coding: utf-8 -*-

import json

menu = {}
menu['local'] = 'Pannbiff'
menu['green'] = 'Svamppilaff'
menu['asia ichi'] = 'Nudlar'

# Öpnna en fil och skriv till den
try:
    my_file = open("file.json", "w")
    json.dump(menu, my_file)
    my_file.close()
    print 'Skrev till file.json'
except IOError:
    print 'Ajaj, filen finns inte!'
    
