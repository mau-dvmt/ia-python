# -*- coding: utf-8 -*-

integers = range(0, 5)
try:
    number = input('Välj en siffra mellan 0 och 5: ')
    print 'Heltal ' + str(number) + ' är ' + str(integers[number])
    print '100 delat med ' + str(number) + ' blir ' + str(100/number)
except IndexError:
    print 'Elementet ' + str(number) + ' existerar inte'
except ArithmeticError:
    print 'Kan inte dela med ' + str(number)
except Exception as e:
    print 'Något annat gick helt fel'
    print e
