# -*- coding: utf-8 -*-

import json

# Öpnna en fil och läs från den
try:
    my_file = open("file.json", "r")
    menu = json.load(my_file)
    my_file.close()
    print 'Dagens meny'
    print 'Local: ' + menu['local']
    print 'Green: ' + menu['green']
    print 'Asia ichi: ' + menu['asia ichi']
except IOError:
    print 'Ajaj, filen finns inte!'
    
