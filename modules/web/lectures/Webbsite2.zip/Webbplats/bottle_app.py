from bottle import run, route, template, request, static_file

@route('/')
def index():
	'''Creates the start page, with content loaded from text file "static/content.txt"

	Returns:
		template: index
	'''
	# Opens the file "static/content.txt" in "read" mode
	my_file = open("static/content.txt", "r")
	# Saves the file content (text) into variable "content"
	content = my_file.read()
	# Closes the file
	my_file.close()
	# Creates and returns the template "index" with the content from file
	return template("index", text=content)

@route('/edit')
def edit():
	'''Creates the edit content page, with current content from text file "static/content.txt"

	Returns:
		template: edit
	'''
	# Opens the file "static/content.txt" in "read" mode
	my_file = open("static/content.txt", "r")
	# Saves the file content (text) into variable "content"
	content = my_file.read()
	# Closes the file
	my_file.close()
	# Creates and returns the template "edit" with the content from file
	return template("edit", text=content)

@route('/save-edit', method="POST")
def save_edit():
	'''Updates the content in "static/content.txt" and returns the updated start page

	Returns:
		template: index
	'''
	#
	content = request.forms.get("info")
	# Opens the file "static/content.txt" in "write" mode
	my_file = open("static/content.txt", "w")
	# Writes the new content to the file
	my_file.write(content)
	# Closes the file
	my_file.close()
	# Creates and returns the template "index" with the new content
	return template("index", text=content)

@route('/static/<filename>')
def server_static(filename):
	'''Handles the routes to our static files

	Returns:
		file : the static file requested by URL
	'''
	return static_file(filename, root="static")
    
# Start our web server
run()
