def program():
    wishes = load_wishes_from_file()

    welcome() # Välkomna användaren

    while True:
        print_menu() # Skriver ut menyn
        user_choice = input("Val: ")
        if user_choice == "1":
            add_wish() # Lägger till en önskning
            wishes = load_wishes_from_file()
        elif user_choice == "2":
            print_wishes(wishes) # Skriver ut önskningarna
        elif user_choice == "3":
            break # Avsluta loopen
        else:
            print("Du valde inte ett giltigt alternativ, försök igen")

    goodbye()

def welcome():
    print("*"*30)
    print("Välkommen till önskelistan!")
    print("*"*30)

def print_menu():
    print("*"*30)
    print("Meny")
    print("*"*30)
    print("1) Lägg till en önskning")
    print("2) Visa önskningar")
    print("3) Avsluta")

def add_wish():
    print("*"*30)
    print("Lägg till en önskning")
    print("*"*30)
    title = input("Vad önskar du dig? ")
    link = input("Länk till saken: ")
    prio = input("Prio (1,2,3): ")

    my_file = open("wishes.txt", "a")
    my_file.write("{};{};{}\n".format(title, link, prio))
    my_file.close()
    

def print_wishes(wishes):
    print("{:<15} {:<10} {:<10}".format("Sak", "Länk", "Prio"))
    for wish in sorted(wishes, key=lambda x: x[2]):
        print("{:<15} {:<10} {:<10}".format(wish[0], wish[1], wish[2]))

def goodbye():
    print("*"*30)
    print("Tack för att du tittade in!")
    print("*"*30)

def load_wishes_from_file():
    wishes = []

    try:
        my_file = open("wishes.txt", "r")
        content = my_file.read()
        my_file.close()
        for row in content.split("\n"):
            if row != "":
                wishes.append(row.split(";"))
        return wishes
    except:
        my_file = open("wishes.txt", "w").close()
        return wishes


program()
