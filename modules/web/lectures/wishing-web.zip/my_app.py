from bottle import run, route, template, static_file, request, redirect
import json

def read_wishes_from_file():
    try:
        my_file = open("storage/wishes.json", "r")
        wishes = json.loads(my_file.read())
        my_file.close()

        return wishes
    except:
        my_file = open("storage/wishes.json", "w")
        my_file.write(json.dumps([]))
        my_file.close()

        return []

@route("/")
def index():
    return template("index", wishes=read_wishes_from_file())

@route("/add-wish", method="POST")
def add_wish():
    wish = {}
    wish["title"] = getattr(request.forms, "title")
    wish["link"] = getattr(request.forms, "link")
    wish["prio"] = getattr(request.forms, "prio")

    wishes = read_wishes_from_file()
    wishes.append(wish)

    my_file = open("storage/wishes.json", "w")
    my_file.write(json.dumps(wishes, indent=4))
    my_file.close()

    redirect("/")

@route("/static/<filename>")
def static_files(filename):
    return static_file(filename, root="static")

run(host="127.0.0.1", port=8080)
