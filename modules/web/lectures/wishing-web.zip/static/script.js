// https://github.com/loktar00/JQuery-Snowfall

$(document).snowfall({
    flakeCount : 100,
    maxSpeed : 5,
    maxSize: 5,
    round: true,
    collection: '#wish'
});

$("#show-form").next().hide();
$("#show-form").on("click", function() {
    $(this).next().slideToggle();
});