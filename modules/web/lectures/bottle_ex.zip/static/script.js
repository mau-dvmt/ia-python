window.onload = start;

function start(){
	$(document).snowfall({
		flakeCount : 100,
		maxSpeed : 5,
		maxSize : 5,
		round: true,
		collection : '#wish'
	});
	
	$("#show-form").click(function(){
		$(this).next().slideToggle()
	});
}