from bottle import run, route, template, static_file, request, redirect

def read_wish_list_from_file():
	wishes = []
	try:
		my_file = open("storage/wish-list.txt", "r", encoding="utf-8")
		content = my_file.read()
		for wish in content.split("\n"):
			if wish != "":
				wishes.append(wish.split(";"))
		return wishes
	except:
		my_file = open("storage/wish-list.txt", "w").close()
		return wishes

@route("/")
def index():
	wish_list = read_wish_list_from_file()
	return template("index", wish_list=wish_list)

@route("/add-wish", method="POST")
def save_wish():
	title = request.forms.get("title")
	link = request.forms.get("link")
	prio = request.forms.get("prio")
	my_file = open("storage/wish-list.txt", "a")
	my_file.write("{};{};{}\n".format(title, link, prio))
	my_file.close()
	redirect("/")

@route("/static/<file_name>")
def static_files(file_name):
	return static_file(file_name, root="static")

run(host="0.0.0.0", port="80", reloader=True)

